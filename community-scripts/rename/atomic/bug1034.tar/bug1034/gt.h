#ifndef _BUG1034_TEST_
#define _BUG1034_TEST_

// #define BASE_PATH "/common_mount_point/test_directory"
#define BASE_PATH "/sme_cluster/global/bug1034_test"

#define CYCLE_TIME   5
#define CYCLE_JITTER 5

#define SUBDIR_FILES 3

#endif	/* ! _BUG1034_TEST_ */
